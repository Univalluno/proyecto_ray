import ray
from ray import serve
from fastapi import FastAPI
from pydantic import BaseModel

# Inicializar Ray y Ray Serve
ray.init()
serve.start(detached=True)

app = FastAPI()

class InputData(BaseModel):
    number: int

# 🔁 Función paralela con @ray.remote
@ray.remote
def es_par(numero):
    return "par" if numero % 2 == 0 else "impar"

# Servicio como microservicio con FastAPI
@serve.deployment
@serve.ingress(app)
class MLModelService:
    @app.post("/predict")
    async def predict(self, data: InputData):
        numero = data.number
        # 🧠 Llama a la función remota
        resultado = await es_par.remote(numero)
        return {"numero": numero, "clasificacion": resultado}

# Despliega el servicio
serve.run(MLModelService.bind())
